args=("$@")
echo -e $(date)
echo -e "whoami -> $(whoami)"
echo "Helo World"
echo "----------------"